//! Standalone Rust surface for pro-rata allocation artifact identities.

pub mod allocation_context;
pub mod allocation_evaluation;
pub mod allocation_roots;
pub mod canonical_order;
pub mod context_validation;
pub mod exact_ratio;
pub mod kernel_types;
pub mod policy_identity;
pub mod proportionality;
pub mod realized_fill;
pub mod realized_statement;
pub mod selection;
pub mod validation;
